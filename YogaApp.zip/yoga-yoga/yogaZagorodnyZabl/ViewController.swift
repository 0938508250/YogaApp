//
//  ViewController.swift
//  yogaZagorodnyZabl
//
//  Created by Даниил on 08.02.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

